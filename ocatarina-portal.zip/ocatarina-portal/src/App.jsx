import React, { useState, useEffect, useRef, useCallback } from "react";
import { createClient } from "@supabase/supabase-js";

/* ============================================================
   O CATARINA — Portal + Redação (Supabase)
   Login da equipe · banco compartilhado · publicação ao vivo
   ============================================================ */

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || "https://dzysyujkefksduusnkpb.supabase.co";
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_KEY || "sb_publishable_foVjR4L0DXOt7c2k5-8JWw_dgZpTWu8";

const PINHEIRO = "#0E3B2E", PINHEIRO_DEEP = "#0a2c22", MAR = "#1D9E75",
  MAR_BRIGHT = "#5fd6ac", VERMELHO = "#C0392B", AREIA = "#F7F6F1", TINTA = "#1A1A18";
const SERIF = "'Lora', Georgia, serif";
const SANS = "'Libre Franklin', Helvetica, Arial, sans-serif";

const SEALS = {
  PLANTAO: { label: "Plantão", bg: VERMELHO, fg: "#fff" },
  POLITICA: { label: "Política", bg: MAR, fg: "#fff" },
  ECONOMIA: { label: "Economia", bg: "rgba(29,158,117,.14)", fg: PINHEIRO, border: "rgba(29,158,117,.45)" },
  CIDADES: { label: "Cidades", bg: "rgba(14,59,46,.1)", fg: PINHEIRO, border: "rgba(14,59,46,.3)" },
  ESPORTES: { label: "Esportes", bg: "rgba(29,158,117,.14)", fg: PINHEIRO, border: "rgba(29,158,117,.45)" },
  VERIFICADO: { label: "Verificado", bg: PINHEIRO, fg: MAR_BRIGHT, check: true },
};

function Symbol({ size = 48, ring = MAR_BRIGHT, w1 = MAR, w2 = "#7d9b8f" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" style={{ display: "block", flex: "none" }}>
      <circle cx="50" cy="50" r="46" fill="none" stroke={ring} strokeWidth="2.2" />
      <circle cx="50" cy="32" r="6.4" fill={VERMELHO} />
      <path d="M30 58 Q40 49 50 56 T72 50" fill="none" stroke={w1} strokeWidth="6.5" strokeLinecap="round" />
      <path d="M30 67 Q40 60 50 65 T70 61" fill="none" stroke={w2} strokeWidth="6.5" strokeLinecap="round" />
    </svg>
  );
}
function Seal({ type, style }) {
  const s = SEALS[type] || SEALS.POLITICA;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6, fontFamily: SANS, fontSize: 11, fontWeight: 700, letterSpacing: ".13em", textTransform: "uppercase", padding: "5px 11px", borderRadius: 4, background: s.bg, color: s.fg, border: s.border ? `1px solid ${s.border}` : "none", ...style }}>
      {s.check ? "✓ " : ""}{s.label}
    </span>
  );
}
function timeAgo(ts) {
  const diff = Date.now() - new Date(ts).getTime();
  if (diff < 0) return "agendada";
  const m = Math.floor(diff / 6e4);
  if (m < 1) return "agora"; if (m < 60) return `há ${m} min`;
  const h = Math.floor(m / 60); if (h < 24) return `há ${h}h`;
  return `há ${Math.floor(h / 24)}d`;
}

// camelCase <-> snake_case do banco
const fromRow = r => ({ id: r.id, title: r.title, summary: r.summary, body: r.body, seal: r.seal, city: r.city, author: r.author, photo: r.photo, featured: r.featured, status: r.status, publishAt: r.publish_at, createdAt: r.created_at });
const toRow = a => ({ title: a.title, summary: a.summary, body: a.body, seal: a.seal, city: a.city, author: a.author, photo: a.photo, featured: a.featured, status: a.status, publish_at: a.publishAt });

const emptyForm = { id: null, title: "", summary: "", body: "", seal: "POLITICA", city: "", author: "Redação O Catarina", photo: "", featured: false, scheduleOn: false, publishAt: "" };

export default function App() {
  const [sb, setSb] = useState(null);
  const [netError, setNetError] = useState(false);
  const [session, setSession] = useState(null);
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState("portal");
  const [showLogin, setShowLogin] = useState(false);
  const [openArticle, setOpenArticle] = useState(null);
  const [toast, setToast] = useState("");

  const flash = (m) => { setToast(m); setTimeout(() => setToast(""), 2800); };

  // inicializar cliente Supabase
  useEffect(() => {
    try {
      const client = createClient(SUPABASE_URL, SUPABASE_KEY);
      setSb(client);
      client.auth.getSession().then(({ data }) => setSession(data.session));
      const { data: sub } = client.auth.onAuthStateChange((_e, s) => setSession(s));
      return () => sub?.subscription?.unsubscribe?.();
    } catch {
      setNetError(true);
      setLoading(false);
    }
  }, []);

  const loadArticles = useCallback(async () => {
    if (!sb) return;
    setLoading(true);
    // logado: vê tudo; visitante: só publicadas (RLS já filtra, mas ordenamos aqui)
    let q = sb.from("noticias").select("*").order("publish_at", { ascending: false });
    const { data, error } = await q;
    if (error) { setNetError(true); setLoading(false); return; }
    setArticles((data || []).map(fromRow));
    setLoading(false);
  }, [sb]);

  useEffect(() => { if (sb) loadArticles(); }, [sb, session, loadArticles]);

  // realtime: atualiza quando alguém da equipe publica
  useEffect(() => {
    if (!sb) return;
    const ch = sb.channel("noticias-rt")
      .on("postgres_changes", { event: "*", schema: "public", table: "noticias" }, () => loadArticles())
      .subscribe();
    return () => { sb.removeChannel(ch); };
  }, [sb, loadArticles]);

  async function saveArticle(form, status) {
    if (!form.title.trim()) { flash("⚠ A manchete é obrigatória."); return false; }
    let publishAt = new Date().toISOString();
    if (form.scheduleOn && form.publishAt) publishAt = new Date(form.publishAt).toISOString();
    const isScheduled = form.scheduleOn && new Date(publishAt).getTime() > Date.now();
    const finalStatus = status === "draft" ? "draft" : isScheduled ? "scheduled" : "published";
    const payload = toRow({ ...form, status: finalStatus, publishAt, city: form.city.trim() || "Santa Catarina", author: form.author.trim() || "Redação O Catarina" });

    // só um destaque por vez
    if (form.featured) await sb.from("noticias").update({ featured: false }).neq("id", form.id || "00000000-0000-0000-0000-000000000000");

    let res;
    if (form.id) res = await sb.from("noticias").update(payload).eq("id", form.id);
    else res = await sb.from("noticias").insert(payload);
    if (res.error) { flash("Erro ao salvar: " + res.error.message); return false; }
    flash(finalStatus === "draft" ? "💾 Rascunho salvo." : finalStatus === "scheduled" ? "🕒 Notícia agendada." : "✓ Publicado no portal!");
    await loadArticles();
    if (finalStatus === "published") setView("portal");
    return true;
  }
  async function delArticle(id) {
    if (!sb) return;
    const { error } = await sb.from("noticias").delete().eq("id", id);
    if (error) return flash("Erro ao excluir: " + error.message);
    flash("Notícia removida."); loadArticles();
  }
  async function publishNow(id) {
    const { error } = await sb.from("noticias").update({ status: "published", publish_at: new Date().toISOString() }).eq("id", id);
    if (error) return flash("Erro: " + error.message);
    flash("✓ Publicado no portal!"); loadArticles();
  }
  async function logout() { await sb.auth.signOut(); setView("portal"); flash("Sessão encerrada."); }

  const isTeam = !!session;
  // visão pública x equipe
  const now = Date.now();
  const visible = isTeam ? articles : articles.filter(a => a.status === "published" && new Date(a.publishAt).getTime() <= now);
  const live = visible.filter(a => a.status === "published" && new Date(a.publishAt).getTime() <= now).sort((a, b) => new Date(b.publishAt) - new Date(a.publishAt));
  const hero = live.find(a => a.featured) || live[0];
  const rest = live.filter(a => hero && a.id !== hero.id);

  if (netError) return <NetError />;

  return (
    <div style={{ fontFamily: SANS, color: TINTA, minHeight: "100vh", background: AREIA }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Libre+Franklin:wght@300;400;500;600;700&display=swap');
        *{box-sizing:border-box}
        .oc-input{font-family:${SANS};font-size:14px;width:100%;padding:11px 13px;border:1px solid rgba(14,59,46,.2);border-radius:9px;background:#fff;color:${TINTA};outline:none;transition:.2s}
        .oc-input:focus{border-color:${MAR};box-shadow:0 0 0 3px rgba(29,158,117,.12)}
        .oc-label{font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:${PINHEIRO};margin-bottom:6px;display:block}
        .oc-tab{cursor:pointer;border:none;background:none;font-family:${SANS};font-weight:600;font-size:13px;padding:9px 15px;border-radius:8px;color:rgba(247,246,241,.7);transition:.2s}
        .oc-tab.active{background:rgba(95,214,172,.16);color:#fff}
        .oc-btn{cursor:pointer;font-family:${SANS};font-weight:600;font-size:13.5px;border:none;border-radius:999px;padding:12px 22px;transition:.2s}
        .oc-card{transition:.25s}.oc-card:hover{transform:translateY(-3px);box-shadow:0 20px 38px -22px rgba(14,59,46,.4)}
        .chip{cursor:pointer;font-size:12px;font-weight:600;padding:7px 13px;border-radius:999px;border:1px solid rgba(14,59,46,.18);background:#fff;color:rgba(26,26,24,.7)}
        .chip.active{background:${PINHEIRO};color:#fff;border-color:${PINHEIRO}}
        .seal-pick{cursor:pointer;border:1.5px solid rgba(14,59,46,.18);background:#fff;border-radius:8px;padding:8px;display:flex;align-items:center;justify-content:center;transition:.18s}
        .seal-pick.sel{border-color:${MAR};box-shadow:0 0 0 3px rgba(29,158,117,.12)}
      `}</style>

      {/* TOPO */}
      <div style={{ background: PINHEIRO_DEEP, color: AREIA, padding: "14px 0", borderBottom: "1px solid rgba(95,214,172,.14)", position: "sticky", top: 0, zIndex: 40 }}>
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "0 24px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16, flexWrap: "wrap" }}>
          <div onClick={() => setView("portal")} style={{ display: "flex", alignItems: "center", gap: 12, cursor: "pointer" }}>
            <Symbol size={40} />
            <div>
              <div style={{ fontFamily: SERIF, fontSize: 22, fontWeight: 500, lineHeight: 1 }}>O Catarina</div>
              <div style={{ fontSize: 9.5, letterSpacing: ".18em", textTransform: "uppercase", color: MAR_BRIGHT, marginTop: 3 }}>Informação de Catarina, para Catarina</div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            {isTeam && (
              <div style={{ display: "flex", gap: 6, background: "rgba(0,0,0,.2)", padding: 5, borderRadius: 11 }}>
                <button className={"oc-tab" + (view === "portal" ? " active" : "")} onClick={() => setView("portal")}>◉ Portal</button>
                <button className={"oc-tab" + (view === "redacao" ? " active" : "")} onClick={() => setView("redacao")}>✎ Redação</button>
              </div>
            )}
            {isTeam ? (
              <button className="oc-btn" style={{ background: "rgba(95,214,172,.14)", color: MAR_BRIGHT, padding: "9px 16px" }} onClick={logout}>Sair</button>
            ) : (
              <button className="oc-btn" style={{ background: MAR, color: "#fff", padding: "9px 18px" }} onClick={() => setShowLogin(true)}>Entrar (equipe)</button>
            )}
          </div>
        </div>
      </div>

      {toast && <div style={{ position: "fixed", bottom: 26, left: "50%", transform: "translateX(-50%)", zIndex: 90, background: PINHEIRO, color: "#fff", fontSize: 14, fontWeight: 500, padding: "13px 24px", borderRadius: 999, boxShadow: "0 16px 40px -10px rgba(14,59,46,.6)" }}>{toast}</div>}

      {loading ? (
        <div style={{ padding: 60, textAlign: "center", color: "rgba(26,26,24,.4)" }}>Carregando…</div>
      ) : view === "redacao" && isTeam ? (
        <Redacao {...{ articles, saveArticle, delArticle, publishNow, session }} />
      ) : (
        <Portal {...{ hero, rest, setOpenArticle, isTeam, onLogin: () => setShowLogin(true) }} />
      )}

      {openArticle && <ArticleModal a={openArticle} onClose={() => setOpenArticle(null)} />}
      {showLogin && <LoginModal sb={sb} onClose={() => setShowLogin(false)} onDone={() => { setShowLogin(false); setView("redacao"); flash("Bem-vindo à redação."); }} />}

      <div style={{ background: PINHEIRO_DEEP, color: "rgba(247,246,241,.5)", textAlign: "center", fontSize: 11.5, letterSpacing: ".08em", padding: 20, marginTop: 40 }}>
        © 2026 O Catarina · Santa Catarina · @ocatarinajornal
      </div>
    </div>
  );
}

/* ---------- LOGIN ---------- */
function LoginModal({ sb, onClose, onDone }) {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState(""); const [pass, setPass] = useState("");
  const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  async function submit() {
    if (!email || !pass) return setMsg("Preencha e-mail e senha.");
    setBusy(true); setMsg("");
    const fn = mode === "login" ? sb.auth.signInWithPassword({ email, password: pass }) : sb.auth.signUp({ email, password: pass });
    const { error } = await fn;
    setBusy(false);
    if (error) return setMsg(error.message);
    if (mode === "signup") return setMsg("Conta criada. Se exigir confirmação, verifique o e-mail e depois entre.");
    onDone();
  }
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(10,44,34,.6)", backdropFilter: "blur(3px)", zIndex: 95, display: "grid", placeItems: "center", padding: 20 }}>
      <div onClick={e => e.stopPropagation()} style={{ background: AREIA, width: "100%", maxWidth: 400, borderRadius: 16, padding: 30, boxShadow: "0 40px 80px -20px rgba(0,0,0,.5)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 11, marginBottom: 18 }}>
          <Symbol size={38} ring={MAR} w1={MAR} w2="#7d9b8f" />
          <div style={{ fontFamily: SERIF, fontSize: 20, color: PINHEIRO }}>Redação O Catarina</div>
        </div>
        <label className="oc-label">E-mail</label>
        <input className="oc-input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="voce@ocatarina.com.br" />
        <div style={{ height: 12 }} />
        <label className="oc-label">Senha</label>
        <input className="oc-input" type="password" value={pass} onChange={e => setPass(e.target.value)} onKeyDown={e => e.key === "Enter" && submit()} placeholder="••••••••" />
        {msg && <div style={{ marginTop: 12, fontSize: 13, color: msg.includes("criada") ? PINHEIRO : VERMELHO }}>{msg}</div>}
        <button className="oc-btn" style={{ background: MAR, color: "#fff", width: "100%", marginTop: 18, opacity: busy ? .6 : 1 }} onClick={submit} disabled={busy}>
          {busy ? "…" : mode === "login" ? "Entrar" : "Criar conta"}
        </button>
        <div style={{ marginTop: 14, textAlign: "center", fontSize: 13, color: "rgba(26,26,24,.6)" }}>
          {mode === "login" ? "Primeiro acesso da equipe? " : "Já tem conta? "}
          <button onClick={() => { setMode(mode === "login" ? "signup" : "login"); setMsg(""); }} style={{ background: "none", border: "none", color: MAR, fontWeight: 600, cursor: "pointer", fontSize: 13 }}>
            {mode === "login" ? "Criar conta" : "Entrar"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------- REDAÇÃO ---------- */
function Redacao({ articles, saveArticle, delArticle, publishNow }) {
  const [form, setForm] = useState(emptyForm);
  const [filter, setFilter] = useState("all");
  const titleRef = useRef(null);
  const up = (k, v) => setForm(f => ({ ...f, [k]: v }));
  function editArticle(a) {
    setForm({ id: a.id, title: a.title, summary: a.summary || "", body: a.body || "", seal: a.seal, city: a.city, author: a.author, photo: a.photo || "", featured: a.featured, scheduleOn: a.status === "scheduled", publishAt: a.status === "scheduled" ? new Date(a.publishAt).toISOString().slice(0, 16) : "" });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  async function save(status) { const ok = await saveArticle(form, status); if (ok) setForm(emptyForm); }

  const counts = { all: articles.length, published: articles.filter(a => a.status === "published").length, scheduled: articles.filter(a => a.status === "scheduled").length, draft: articles.filter(a => a.status === "draft").length };
  const listed = articles.filter(a => filter === "all" ? true : a.status === filter).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  return (
    <div style={{ maxWidth: 1180, margin: "0 auto", padding: "28px 24px", display: "grid", gridTemplateColumns: "minmax(0,1.05fr) minmax(0,1fr)", gap: 30, alignItems: "start" }}>
      <div style={{ background: "#fff", borderRadius: 16, padding: "26px 26px 22px", border: "1px solid rgba(14,59,46,.08)", boxShadow: "0 18px 50px -34px rgba(14,59,46,.5)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
          <span style={{ width: 4, height: 22, background: MAR, borderRadius: 2 }} />
          <h2 style={{ fontFamily: SERIF, fontSize: 21, color: PINHEIRO, margin: 0 }}>{form.id ? "Editar notícia" : "Nova notícia"}</h2>
        </div>
        <label className="oc-label">Manchete *</label>
        <input ref={titleRef} className="oc-input" style={{ fontFamily: SERIF, fontSize: 16 }} value={form.title} onChange={e => up("title", e.target.value)} placeholder="Assembleia aprova novo marco do saneamento…" />
        <div style={{ height: 14 }} />
        <label className="oc-label">Linha de apoio (resumo)</label>
        <textarea className="oc-input" rows={2} value={form.summary} onChange={e => up("summary", e.target.value)} placeholder="Resumo factual em uma ou duas linhas." style={{ resize: "vertical" }} />
        <div style={{ height: 14 }} />
        <label className="oc-label">Corpo da matéria</label>
        <textarea className="oc-input" rows={6} value={form.body} onChange={e => up("body", e.target.value)} placeholder="Texto completo. Pule uma linha para separar parágrafos." style={{ resize: "vertical" }} />
        <div style={{ height: 16 }} />
        <label className="oc-label">Editoria / Selo</label>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8 }}>
          {Object.keys(SEALS).map(k => <div key={k} className={"seal-pick" + (form.seal === k ? " sel" : "")} onClick={() => up("seal", k)}><Seal type={k} /></div>)}
        </div>
        {form.seal === "PLANTAO" && <div style={{ marginTop: 8, fontSize: 12, color: VERMELHO }}>⚠ Vermelho é só para última hora. Use com parcimônia.</div>}
        <div style={{ height: 16 }} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <div><label className="oc-label">Cidade</label><input className="oc-input" value={form.city} onChange={e => up("city", e.target.value)} placeholder="Florianópolis" /></div>
          <div><label className="oc-label">Autoria</label><input className="oc-input" value={form.author} onChange={e => up("author", e.target.value)} placeholder="Redação O Catarina" /></div>
        </div>
        <div style={{ height: 14 }} />
        <label className="oc-label">Foto (URL)</label>
        <input className="oc-input" value={form.photo} onChange={e => up("photo", e.target.value)} placeholder="https://…  (vazio = fundo da marca)" />
        {form.photo && <div style={{ marginTop: 10, borderRadius: 9, overflow: "hidden", aspectRatio: "16/7", background: PINHEIRO }}><img src={form.photo} alt="" referrerPolicy="no-referrer" onError={e => (e.target.style.display = "none")} style={{ width: "100%", height: "100%", objectFit: "cover" }} /></div>}
        <div style={{ height: 18 }} />
        <div style={{ display: "flex", alignItems: "center", gap: 18, flexWrap: "wrap" }}>
          <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13.5, cursor: "pointer", color: PINHEIRO, fontWeight: 500 }}><input type="checkbox" checked={form.featured} onChange={e => up("featured", e.target.checked)} style={{ width: 17, height: 17, accentColor: MAR }} />Manchete principal</label>
          <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13.5, cursor: "pointer", color: PINHEIRO, fontWeight: 500 }}><input type="checkbox" checked={form.scheduleOn} onChange={e => up("scheduleOn", e.target.checked)} style={{ width: 17, height: 17, accentColor: MAR }} />Agendar</label>
          {form.scheduleOn && <input className="oc-input" type="datetime-local" style={{ width: "auto" }} value={form.publishAt} onChange={e => up("publishAt", e.target.value)} />}
        </div>
        <div style={{ height: 22 }} />
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <button className="oc-btn" style={{ background: MAR, color: "#fff" }} onClick={() => save("publish")}>{form.scheduleOn && form.publishAt ? "🕒 Agendar" : "✓ Publicar agora"}</button>
          <button className="oc-btn" style={{ background: "rgba(14,59,46,.08)", color: PINHEIRO }} onClick={() => save("draft")}>💾 Rascunho</button>
          {form.id && <button className="oc-btn" style={{ background: "none", color: "rgba(26,26,24,.5)" }} onClick={() => setForm(emptyForm)}>Cancelar</button>}
        </div>
      </div>

      <div>
        <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
          {[["all", "Todas"], ["published", "Publicadas"], ["scheduled", "Agendadas"], ["draft", "Rascunhos"]].map(([k, l]) => <button key={k} className={"chip" + (filter === k ? " active" : "")} onClick={() => setFilter(k)}>{l} <span style={{ opacity: .6 }}>{counts[k]}</span></button>)}
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {listed.length === 0 && <div style={{ textAlign: "center", color: "rgba(26,26,24,.4)", fontSize: 14, padding: "40px 0" }}>Nenhuma notícia aqui ainda.</div>}
          {listed.map(a => (
            <div key={a.id} className="oc-card" style={{ background: "#fff", borderRadius: 12, border: "1px solid rgba(14,59,46,.08)", padding: 12, display: "flex", gap: 13 }}>
              <div style={{ width: 84, height: 64, borderRadius: 8, flex: "none", overflow: "hidden", background: `radial-gradient(130% 120% at 40% 20%,#1d6048,${PINHEIRO})` }}>{a.photo && <img src={a.photo} alt="" referrerPolicy="no-referrer" onError={e => (e.target.style.display = "none")} style={{ width: "100%", height: "100%", objectFit: "cover" }} />}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", gap: 7, alignItems: "center", marginBottom: 5, flexWrap: "wrap" }}>
                  <Seal type={a.seal} style={{ fontSize: 9.5, padding: "3px 8px" }} />
                  {a.featured && a.status === "published" && <span style={{ fontSize: 9.5, fontWeight: 700, letterSpacing: ".1em", color: MAR, textTransform: "uppercase" }}>★ Destaque</span>}
                  <StatusPill status={a.status} publishAt={a.publishAt} />
                </div>
                <div style={{ fontFamily: SERIF, fontSize: 15, color: PINHEIRO, lineHeight: 1.25, fontWeight: 600 }}>{a.title}</div>
                <div style={{ fontSize: 10.5, letterSpacing: ".08em", textTransform: "uppercase", color: "rgba(26,26,24,.45)", marginTop: 5 }}>{a.city}</div>
                <div style={{ display: "flex", gap: 14, marginTop: 9 }}>
                  <button onClick={() => editArticle(a)} style={btnLink(MAR)}>Editar</button>
                  {a.status !== "published" && <button onClick={() => publishNow(a.id)} style={btnLink(PINHEIRO)}>Publicar agora</button>}
                  <button onClick={() => delArticle(a.id)} style={btnLink(VERMELHO)}>Excluir</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
function btnLink(c) { return { background: "none", border: "none", cursor: "pointer", fontFamily: SANS, fontSize: 12, fontWeight: 600, color: c, padding: 0 }; }
function StatusPill({ status, publishAt }) {
  const map = { published: { t: "● No ar", c: MAR }, scheduled: { t: "🕒 " + new Date(publishAt).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }), c: "#b5862f" }, draft: { t: "Rascunho", c: "rgba(26,26,24,.45)" } };
  const s = map[status] || map.draft;
  return <span style={{ fontSize: 10, fontWeight: 700, color: s.c }}>{s.t}</span>;
}

/* ---------- PORTAL ---------- */
function Portal({ hero, rest, setOpenArticle, isTeam, onLogin }) {
  if (!hero) return (
    <div style={{ maxWidth: 1180, margin: "0 auto", padding: "80px 24px", textAlign: "center", color: "rgba(26,26,24,.45)" }}>
      <Symbol size={60} ring={MAR} w1={MAR} w2="#7d9b8f" />
      <p style={{ marginTop: 18, fontSize: 16 }}>Nenhuma notícia publicada ainda.{!isTeam && <> <button onClick={onLogin} style={{ background: "none", border: "none", color: MAR, fontWeight: 600, cursor: "pointer", fontSize: 16 }}>Entre como equipe</button> para publicar.</>}</p>
    </div>
  );
  return (
    <div style={{ maxWidth: 1180, margin: "0 auto", padding: "28px 24px 10px" }}>
      <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1.9fr) minmax(0,1fr)", gap: 30, alignItems: "start" }}>
        <article onClick={() => setOpenArticle(hero)} className="oc-card" style={{ cursor: "pointer", position: "relative", borderRadius: 14, overflow: "hidden", background: PINHEIRO, boxShadow: "0 30px 60px -30px rgba(14,59,46,.55)" }}>
          <div style={{ aspectRatio: "16/10", position: "relative", background: `radial-gradient(120% 90% at 70% 10%,#1d6048,${PINHEIRO} 45%,${PINHEIRO_DEEP})` }}>
            {hero.photo && <img src={hero.photo} alt="" referrerPolicy="no-referrer" onError={e => (e.target.style.display = "none")} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />}
            <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg,rgba(14,59,46,.15) 25%,rgba(10,44,34,.55) 60%,rgba(10,44,34,.96) 100%)" }} />
            <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, padding: "30px 32px", color: "#fff" }}>
              <Seal type={hero.seal} style={{ marginBottom: 14 }} />
              <h1 style={{ fontFamily: SERIF, fontWeight: 600, fontSize: "clamp(24px,3vw,40px)", lineHeight: 1.1, margin: 0, letterSpacing: "-.01em" }}>{hero.title}</h1>
              {hero.summary && <p style={{ marginTop: 12, fontSize: 15.5, color: "rgba(247,246,241,.88)", fontWeight: 300, maxWidth: 620 }}>{hero.summary}</p>}
              <div style={{ marginTop: 16, fontSize: 11, letterSpacing: ".13em", textTransform: "uppercase", color: MAR_BRIGHT }}>{hero.city} · {timeAgo(hero.publishAt)} · {hero.author}</div>
            </div>
          </div>
        </article>
        <aside style={{ display: "flex", flexDirection: "column", gap: 18 }}>
          {rest.slice(0, 4).map(a => (
            <div key={a.id} onClick={() => setOpenArticle(a)} style={{ cursor: "pointer", paddingBottom: 18, borderBottom: "1px solid rgba(14,59,46,.12)" }}>
              <Seal type={a.seal} style={{ marginBottom: 8 }} />
              <h3 style={{ fontFamily: SERIF, fontWeight: 600, fontSize: 18, lineHeight: 1.22, color: PINHEIRO, margin: 0 }}>{a.title}</h3>
              <div style={{ marginTop: 7, fontSize: 10.5, letterSpacing: ".1em", textTransform: "uppercase", color: "rgba(26,26,24,.5)" }}>{a.city} · {timeAgo(a.publishAt)}</div>
            </div>
          ))}
          {rest.length === 0 && <div style={{ fontSize: 13, color: "rgba(26,26,24,.4)" }}>Publique mais notícias para preencher esta coluna.</div>}
        </aside>
      </div>
      {rest.length > 4 && (
        <>
          <div style={{ display: "flex", alignItems: "center", gap: 14, margin: "44px 0 22px" }}>
            <h2 style={{ fontFamily: SERIF, fontWeight: 600, fontSize: 22, color: PINHEIRO, margin: 0 }}>Últimas</h2>
            <span style={{ height: 3, flex: 1, background: MAR, borderRadius: 2 }} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(260px,1fr))", gap: 24 }}>
            {rest.slice(4).map(a => (
              <article key={a.id} onClick={() => setOpenArticle(a)} className="oc-card" style={{ cursor: "pointer", background: "#fff", borderRadius: 12, overflow: "hidden", border: "1px solid rgba(14,59,46,.08)" }}>
                <div style={{ aspectRatio: "3/2", position: "relative", background: `radial-gradient(130% 120% at 40% 20%,#1d6048,${PINHEIRO})` }}>
                  {a.photo && <img src={a.photo} alt="" referrerPolicy="no-referrer" onError={e => (e.target.style.display = "none")} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />}
                  <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg,rgba(14,59,46,.12),rgba(10,44,34,.7))" }} />
                  <div style={{ position: "absolute", top: 12, left: 12 }}><Seal type={a.seal} /></div>
                </div>
                <div style={{ padding: "16px 16px 20px" }}>
                  <h3 style={{ fontFamily: SERIF, fontWeight: 600, fontSize: 17, lineHeight: 1.24, color: PINHEIRO, margin: 0 }}>{a.title}</h3>
                  {a.summary && <p style={{ marginTop: 7, fontSize: 13, color: "rgba(26,26,24,.66)", fontWeight: 300 }}>{a.summary}</p>}
                  <div style={{ marginTop: 12, fontSize: 10, letterSpacing: ".1em", textTransform: "uppercase", color: "rgba(26,26,24,.45)" }}>{a.city} · {timeAgo(a.publishAt)}</div>
                </div>
              </article>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

/* ---------- MODAL ARTIGO ---------- */
function ArticleModal({ a, onClose }) {
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(10,44,34,.55)", backdropFilter: "blur(3px)", zIndex: 80, display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "40px 20px", overflowY: "auto" }}>
      <div onClick={e => e.stopPropagation()} style={{ background: AREIA, maxWidth: 720, width: "100%", borderRadius: 16, overflow: "hidden", boxShadow: "0 40px 80px -20px rgba(0,0,0,.5)" }}>
        <div style={{ aspectRatio: "16/8", position: "relative", background: `radial-gradient(120% 90% at 70% 10%,#1d6048,${PINHEIRO})` }}>
          {a.photo && <img src={a.photo} alt="" referrerPolicy="no-referrer" onError={e => (e.target.style.display = "none")} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />}
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg,rgba(14,59,46,.1),rgba(10,44,34,.55))" }} />
          <button onClick={onClose} style={{ position: "absolute", top: 14, right: 14, width: 34, height: 34, borderRadius: "50%", border: "none", background: "rgba(0,0,0,.4)", color: "#fff", fontSize: 18, cursor: "pointer" }}>×</button>
          <div style={{ position: "absolute", left: 24, bottom: 18 }}><Seal type={a.seal} /></div>
        </div>
        <div style={{ padding: "26px 32px 36px" }}>
          <h1 style={{ fontFamily: SERIF, fontWeight: 600, fontSize: 30, lineHeight: 1.14, color: PINHEIRO, margin: 0, letterSpacing: "-.01em" }}>{a.title}</h1>
          <div style={{ marginTop: 12, fontSize: 11, letterSpacing: ".12em", textTransform: "uppercase", color: MAR, fontWeight: 600 }}>{a.city} · {timeAgo(a.publishAt)} · {a.author}</div>
          {a.summary && <p style={{ marginTop: 18, fontFamily: SERIF, fontStyle: "italic", fontSize: 18, lineHeight: 1.5, color: "rgba(26,26,24,.78)" }}>{a.summary}</p>}
          <div style={{ height: 1, background: "rgba(14,59,46,.12)", margin: "20px 0" }} />
          {(a.body || "").split("\n").filter(Boolean).map((p, i) => <p key={i} style={{ fontSize: 15.5, lineHeight: 1.7, color: "rgba(26,26,24,.85)", marginBottom: 14 }}>{p}</p>)}
          {!a.body && <p style={{ fontSize: 14, color: "rgba(26,26,24,.45)" }}>Sem corpo de texto.</p>}
          <div style={{ marginTop: 22, paddingTop: 18, borderTop: "1px solid rgba(14,59,46,.12)", display: "flex", alignItems: "center", gap: 10, color: "rgba(26,26,24,.5)", fontSize: 12 }}>
            <Symbol size={26} ring={MAR} w1={MAR} w2="#7d9b8f" /> O Catarina · @ocatarinajornal
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- ERRO DE REDE ---------- */
function NetError() {
  return (
    <div style={{ fontFamily: SANS, minHeight: "100vh", background: AREIA, display: "grid", placeItems: "center", padding: 30 }}>
      <div style={{ maxWidth: 480, textAlign: "center" }}>
        <Symbol size={64} ring={MAR} w1={MAR} w2="#7d9b8f" />
        <h2 style={{ fontFamily: SERIF, color: PINHEIRO, marginTop: 18 }}>Sem conexão com o Supabase</h2>
        <p style={{ color: "rgba(26,26,24,.65)", fontSize: 14.5, lineHeight: 1.6 }}>
          Não foi possível conectar ao banco de dados. Verifique se as variáveis <b>VITE_SUPABASE_URL</b> e <b>VITE_SUPABASE_KEY</b> estão configuradas na Vercel, e se o projeto Supabase está ativo.
        </p>
      </div>
    </div>
  );
}
